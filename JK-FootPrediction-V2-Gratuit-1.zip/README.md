# JK Prédiction

Application de prédiction football gratuite :
PWA frontend + backend Flask + SportMonks + moteur Poisson.

## Structure
- `frontend/` : interface PWA installable sur Android
- `backend/` : API Flask et moteur d'analyse
- `backend/services/sportmonks.py` : récupération des données SportMonks
- `backend/services/analysis.py` : calculs 1N2, BTTS, Over/Under et scores exacts
- `.env.example` : configuration

## Démarrage du backend
```bash
cd backend
pip install -r requirements.txt
export SPORTMONKS_TOKEN="VOTRE_TOKEN"
python app.py
```

Le serveur démarre sur `http://127.0.0.1:5000`.

## Déploiement PythonAnywhere
Le fichier WSGI à utiliser est `backend/wsgi.py`.
Adaptez `PROJECT_PATH` à votre chemin PythonAnywhere.

## Frontend
Le frontend est volontairement en HTML/CSS/JavaScript sans framework afin d'être facile à modifier depuis un téléphone/GitHub.
Changez `API_BASE_URL` dans `frontend/app.js` pour pointer vers votre backend HTTPS.

## Important
Le projet est conçu pour votre propre application. Il n'implémente aucun abonnement ni paiement.


## Document d'architecture
Voir `ARCHITECTURE_JK_FOOTPREDICTION.md` pour la feuille de route complète de JK FootPrédiction.
