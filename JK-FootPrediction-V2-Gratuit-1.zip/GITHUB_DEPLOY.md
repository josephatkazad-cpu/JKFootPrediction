# Mise en ligne rapide

## Backend
1. Envoyer `backend/` sur PythonAnywhere.
2. Installer `requirements.txt`.
3. Mettre `SPORTMONKS_TOKEN` dans les variables d'environnement ou la configuration WSGI.
4. Configurer `wsgi.py`.
5. Tester `/health`.

## Frontend
Le dossier `frontend/` peut être publié sur GitHub Pages, Netlify ou Vercel.
Puis modifier `API_BASE_URL` dans `frontend/app.js` avec l'URL HTTPS du backend.

## APK
Une fois la PWA en ligne et fonctionnelle, elle peut être installée depuis Chrome Android via l'installation de l'application.
