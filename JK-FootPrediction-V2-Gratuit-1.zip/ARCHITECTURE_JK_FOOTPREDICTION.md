# JK FootPrédiction — Architecture et feuille de route

## Objectif

JK FootPrédiction est une application football gratuite pour les utilisateurs.
Elle repose sur une PWA installable sur Android, un backend Python hébergé sur PythonAnywhere
et une source de données football (SportMonks dans la configuration actuelle).

> Ce document décrit une architecture pour le propre projet JK FootPrédiction.
> Il ne copie ni ne contourne les protections d'une application tierce.

## Architecture globale

```text
Téléphone Android
      |
      v
JK FootPrédiction (PWA)
      |
      | HTTPS / JSON
      v
Backend Python (Flask)
      |
      v
SportMonks API
      |
      v
Historique + statistiques
      |
      v
Moteur d'analyse
      |
      +--> Forme récente
      +--> Attaque / défense
      +--> Classement
      +--> H2H
      +--> Loi de Poisson
      +--> Matrice des scores 0-0 à 9-9
      |
      v
Résultats en pourcentage
```

## Étape 1 — Données sportives

Le moteur doit récupérer, pour chaque match réel :

- ID SportMonks du match ;
- équipes domicile et extérieur ;
- compétition ;
- date et heure ;
- 5 à 10 derniers matchs de chaque équipe ;
- buts marqués et encaissés ;
- résultats domicile/extérieur ;
- classement ;
- confrontations directes (H2H) lorsque disponibles ;
- statistiques de match disponibles : corners, cartons, fautes, tirs cadrés, etc.

SportMonks reste la source principale de ce projet. D'autres fournisseurs gratuits
(API-Football/Football-Data.org) peuvent être étudiés comme solutions de secours,
mais leurs limites et leurs conditions doivent être vérifiées avant utilisation.

## Étape 2 — Backend et moteur d'analyse

Le backend Flask reçoit l'ID d'un match réel.

Il récupère les données nécessaires, calcule les indicateurs et renvoie un JSON structuré
au frontend.

### Loi de Poisson

Pour un événement ayant une moyenne lambda :

P(X=k) = e^(-lambda) * lambda^k / k!

La valeur lambda doit être estimée à partir des données historiques réellement disponibles,
et non d'une valeur fixe en production.

### Matrice des scores exacts

Le moteur construit une matrice de 0-0 à 9-9 :

P(i,j) = P(domicile=i) * P(extérieur=j)

Les probabilités sont ensuite utilisées pour extraire les marchés.

### 1N2

- 1 : somme des scores où domicile > extérieur ;
- N : somme des scores où domicile = extérieur ;
- 2 : somme des scores où extérieur > domicile.

### Over / Under

Pour un seuil t :

Over t = somme des probabilités où buts_domicile + buts_extérieur > t.

Le moteur doit fournir au minimum :

- Over/Under 1,5 ;
- Over/Under 2,5 ;
- Over/Under 3,5.

### Double chance

- 1N = victoire domicile + nul ;
- N2 = nul + victoire extérieur ;
- 12 = victoire domicile + victoire extérieur.

### BTTS

BTTS Oui correspond à la somme des probabilités où les deux équipes marquent au moins un but.

### Scores exacts

Le moteur trie la matrice et renvoie les 5 scores les plus probables.

## Marchés statistiques complémentaires

Pour les corners, cartons jaunes, fautes et tirs cadrés :

1. calculer les moyennes historiques disponibles ;
2. estimer lambda ;
3. appliquer la loi de Poisson lorsque cette hypothèse est raisonnable ;
4. afficher l'espérance et les probabilités de dépassement.

Exemples de seuils :

- Corners : Over 8,5 / 9,5 / 10,5 ;
- Cartons jaunes : Over 3,5 / 4,5 / 5,5 ;
- Fautes : seuils configurables ;
- Tirs cadrés : total et estimation par équipe.

Ces marchés doivent afficher un indicateur de qualité des données lorsqu'une statistique
n'est pas disponible ou lorsque l'échantillon historique est insuffisant.

## Handicap asiatique

Le moteur peut calculer les probabilités pour des lignes comme +1,5 ou -1,5
en appliquant virtuellement la ligne à chaque score de la matrice.

Pour les lignes avec quart de but (par exemple 0,25 ou 0,75), le calcul devra être
décomposé en deux lignes de demi-buts avant une éventuelle implémentation de rendement
financier. La première version peut se limiter aux lignes demi-but.

## Réponse JSON du backend

Le frontend doit recevoir une structure de ce type :

```json
{
  "ok": true,
  "fixture": 123456,
  "analysis": {
    "match": {},
    "form": {},
    "standings": {},
    "h2h": {},
    "expectedGoals": {},
    "1N2": {},
    "doubleChance": {},
    "BTTS": {},
    "overUnder": {},
    "asianHandicap": {},
    "corners": {},
    "yellowCards": {},
    "fouls": {},
    "shotsOnTarget": {},
    "topScores": [],
    "dataQuality": {}
  }
}
```

## Étape 3 — Interface PWA

Le frontend de JK FootPrédiction utilise HTML/CSS/JavaScript afin de rester simple
à maintenir depuis GitHub et un téléphone.

La PWA doit contenir :

- `manifest.json` ;
- `service-worker.js` ;
- interface responsive ;
- thème sombre ;
- installation sur Android ;
- pages Aujourd'hui et Demain ;
- liste des matchs par compétition ;
- bouton `Analyser →` pour chaque match ;
- écran d'analyse détaillé ;
- indicateur « données disponibles ».

## Étape 4 — Installation Android

Une fois la PWA publiée avec HTTPS, elle peut être installée depuis Chrome Android
comme application.

Pour obtenir un fichier APK partageable, une chaîne de packaging PWA/TWA peut être
utilisée. Le projet doit être testé après chaque génération.

## Étape 5 — Gratuité

JK FootPrédiction n'intègre aucun abonnement obligatoire dans cette version.

La gratuité concerne l'accès utilisateur à l'application. Les coûts ou limites éventuels
des fournisseurs de données et de l'hébergement restent indépendants de l'interface.

## Ordre recommandé de développement

1. Faire fonctionner `/health`.
2. Faire fonctionner `/api/fixtures?date=YYYY-MM-DD`.
3. Afficher les vrais matchs dans la PWA.
4. Faire fonctionner `Analyser →` avec l'ID réel.
5. Ajouter les 5 à 10 derniers matchs.
6. Ajouter classement et H2H.
7. Calculer les lambdas à partir des historiques.
8. Activer la matrice 0-0 à 9-9.
9. Ajouter 1N2, BTTS, Over/Under et Top 5.
10. Ajouter corners/cartons/fautes/tirs cadrés lorsque les données sont disponibles.
11. Ajouter l'indicateur de qualité des données.
12. Publier la PWA et l'installer sur Android.
13. Générer éventuellement un APK partageable.
